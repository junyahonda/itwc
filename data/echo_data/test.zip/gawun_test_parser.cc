#include <iostream>
#include <string>
#include <map>
#include "config_parser.h"
#include <map>
std::map<std::string, std::string> mapping;


std::string path_from_config(const char* file_name, std::string str_static){
	int port = 8080;
	NginxConfigParser parser;
    NginxConfig out_config;

    bool success =  parser.Parse(file_name, &out_config, &port);
    std::cout << "--ORIGINAL--\n" <<out_config.ToString() << std::endl;

    std::map<std::string,std::string> temp;
    out_config.temp(0,temp);

    // bool is_static_flag = false;
    // std::string str_static_path = "";
    for (auto& t : temp){

    	// if(is_static_flag == true){
    	// 	str_static_path = t.second;
    	// 	is_static_flag = false;
    	// }
    	// else if(t.second == "/static"){
    	// 	is_static_flag = true;
    	// }
    	
    	std::cout << "[" << t.first << ", "<< t.second << "]\n";
    }
    // std::cout << "\nThe static path is " << str_static_path << std::endl;
    // std::cout << "The echo path is " << str_echo_path << std::endl;


    return  "";

// 	if(!token_bank.empty()){
//       if((--token_bank.end())->second == "/static"){
//         get_static_path(tokens_[1])
//       }
//     }
}


// std::string path_from_config(const char* file_name, std::string str_static){
// int port = 8080;
// 	NginxConfigParser parser;
//     NginxConfig out_config;

//     bool success =  parser.Parse(file_name, &out_config, &port);
//     std::string output = out_config.ToString();
//     int location = output.find(str_static);

//     // out_config
//     location = location + std::string(str_static).size();
//     int start_point = 0, end_point = 0;

//     while( start_point == 0 || end_point == 0 ){
//     	if(output[location] == '{'){
//     		start_point = location+1;
//     	}
//     	else if(output[location] == '}'){
//     		end_point = location-1;
//     	}
//     	location ++;
//     } 

//     std::string rough_format_path = output.substr(start_point, end_point-start_point);
//     std::string refined_format_path = "";

//     for(auto i =0; i < rough_format_path.size(); i++){
//     	if(rough_format_path[i] != '\n' && rough_format_path[i] != ' ' && rough_format_path[i] != ';' ){
//     		refined_format_path += rough_format_path[i];
//     	}
//     }

//     return  refined_format_path;


// }



// function type string
// arguments 1: filename , 2: "/static" 
// return type : modified string 
int main(){
	std::string path = path_from_config("test_config3","/static");
	mapping["/static"] = path;
	std::cout << path << std::endl;
    return 1;
}
